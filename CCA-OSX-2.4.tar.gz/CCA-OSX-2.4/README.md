Color Contrast Analyser for OSX
===============================

The Colour Contrast Analyser for Mac OSX was developed by Cédric Trévisan Based on the Windows version developed by Jun in collaboration with Steve Faulkner.

> This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
