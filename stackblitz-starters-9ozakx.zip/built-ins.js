const path = require('path');
const os = require('os');
const crypto = require('crypto');

console.log('Current directory:', __dirname);
console.log('Home directory:', os.homedir());
console.log(
  'Hashed string:',
  crypto.createHash('sha256').update('hello').digest('hex')
);
