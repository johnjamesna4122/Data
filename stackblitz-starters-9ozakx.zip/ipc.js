const { fork } = require('child_process');

if (process.argv[2] === 'child') {
  // Child process logic
  process.on('message', (message) => {
    console.log('Message from parent process:', message);

    // Send a message back to the parent process
    process.send('Hello parent process!');
  });
} else {
  // Parent process logic
  const childProcess = fork(__filename, ['child']);

  // Listen for messages from the child process
  childProcess.on('message', (message) => {
    console.log('Message from child process:', message);
  });

  // Send a message to the child process
  childProcess.send('Hello child process!');
}
