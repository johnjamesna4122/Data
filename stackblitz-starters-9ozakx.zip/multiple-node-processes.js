const { spawn } = require('child_process');

const numProcesses = 12;

for (let i = 0; i < numProcesses; i++) {
  // Spawning a new empty child process (using 'node' with no arguments)
  const child = spawn('node');

  // Adding event listeners for logging purposes
  child.on('close', (code) => {
    console.log(`Child process ${i} exited with code ${code}`);
  });

  child.on('error', (err) => {
    console.error(`Failed to start child process ${i}: ${err}`);
  });

  console.log(`Spawned child process ${i + 1} with PID ${child.pid}`);
}
