setTimeout(() => {
  console.log('This will run after 2 seconds');
}, 2000);

const intervalId = setInterval(() => {
  console.log('This runs every 1 second');
}, 1000);

setTimeout(() => {
  clearInterval(intervalId);
}, 5000);
